this.splash = this.splash || {};

splash.assets = [
	{name:'splash_background', src: 'scene/splash/images/background.png',  type: 'image'},
	{name:'bg-frame',          src: 'scene/splash/images/bg-frame.jpg',    type: 'image'},
	{name:'progress_bg',       src: 'scene/splash/images/progress_bg.png', type: 'image'},
	{name:'progress',          src: 'scene/splash/images/progress.png',    type: 'image'},
];
