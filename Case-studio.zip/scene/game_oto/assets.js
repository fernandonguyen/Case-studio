this.gameOto = this.gameOto || {};

gameOto.assets = [
	{name:'background', src: 'scene/gameOto/images/backgroung.jpg',  type: 'image'},
	{name:'spriteOto',  src: 'scene/gameOto/images/oto.png',         type: 'image'},
	{name:'bom',        src: 'scene/gameOto/images/bom.png',         type: 'image'},
	{name:'heart',      src: 'scene/gameOto/images/heart.png',       type: 'image'},
];
