//Sound

this.Home = this.Home || {};

Home.Media = function() {
	this.sound_fire       = new RedT.Sound('sound_fire');
	this.sound_toPlayer   = new RedT.Sound('sound_toPlayer');
	this.sound_changerPow = new RedT.Sound('sound_changerPow');
}
