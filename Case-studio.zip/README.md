Phát triển game và thư viện quản lý canvas theo mô hình quản lý cảnh và nút.


Code by RedT
